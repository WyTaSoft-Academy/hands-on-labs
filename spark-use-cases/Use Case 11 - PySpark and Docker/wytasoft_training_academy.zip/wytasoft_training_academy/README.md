# training_spark by WyTaSoft

docker-compose down --remove-orphans

docker-compose build   

docker-compose up