#!/bin/bash

# Wait for 10 seconds to ensure Kafka is ready
sleep 10

# Run the Python script
python /wytasoft_training_academy/src/main/py/com/wts/training/app/job/CommentProducer.py
