from kafka import KafkaProducer
import random
import time
import json
from datetime import datetime
from src.main.py.com.wts.training.app.utility.PrimaryConstants import PrimaryConstants

class CommentProducer:
    def __init__(self, kafka_server, topic):
        """
        Initializes the Kafka producer and sets up the list of comments.

        :param kafka_server: Address of the Kafka server.
        :param topic: Kafka topic where the comments will be sent.
        """
        self.producer = KafkaProducer(  # This should be KafkaProducer, not CommentProducer
            bootstrap_servers=kafka_server,
            value_serializer=lambda v: json.dumps(v).encode('utf-8')
        )
        self.topic = topic
        self.comments = [
            "I love this product, it's fantastic!",
            "Terrible service, very disappointed.",
            "This is okay, not the best but works.",
            "Absolutely amazing experience, highly recommend!",
            "Awful, will never buy again!",
            "Great customer support, helped me a lot."
        ]

    def generate_comment(self):
        """
        Generates a random comment with a timestamp.

        :return: A dictionary containing a randomly selected comment and a timestamp.
        """
        return {
            "comment": random.choice(self.comments),
            "timestamp": datetime.now().isoformat()  # Send timestamp as ISO 8601 formatted string
        }

    def send_comments(self, interval=2):
        """
        Continuously sends comments to the specified Kafka topic at a given interval.

        :param interval: Time interval between sending messages, in seconds.
        """
        while True:
            comment = self.generate_comment()
            self.producer.send(self.topic, comment)
            print(f"Sent: {comment}")
            time.sleep(interval)

# Usage
if __name__ == "__main__":
    kafka_server = PrimaryConstants.KAFKA_BOOTSTRAP_SERVERS
    topic = PrimaryConstants.KAFKA_TOPIC_NAME

    # Create an instance of the CommentProducer
    producer = CommentProducer(kafka_server, topic)


    # Start sending comments with a 2-second interval
    producer.send_comments(interval=2)
