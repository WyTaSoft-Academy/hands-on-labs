import logging

from src.main.py.com.wts.training.app.writer.PrimaryWriter import PrimaryWriter
from src.main.py.com.wts.training.app.utility.PrimaryUtilities import PrimaryUtilities
from src.main.py.com.wts.training.app.common.PrimaryRunner import PrimaryRunner
from src.main.py.com.wts.training.app.reader.PrimaryReader import PrimaryReader
from src.main.py.com.wts.training.app.utility.PrimaryConstants import PrimaryConstants

from src.main.py.com.wts.training.sessionmanager.SparkSessionManager import SparkSessionManager


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def main(env: str, absolute_config_path: str):
    """
  Main entry point for the PySpark job.

  :param env: Environment name, e.g., "dev", "test", "prod"
  :param absolute_config_path: Path to the configuration file
  """

    # Step 1: Initialize Spark Session using the SparkSessionManager
    spark_session = SparkSessionManager.fetch_spark_session(PrimaryConstants.APPLICATION_NAME)

    # Step 2: Read configuration file
    # Path to the YAML configuration file
    yaml_file_path = '/wytasoft_training_academy/resources/application.yaml'

    # Load the configuration
    config = PrimaryUtilities.read_yaml_config(yaml_file_path)

    logger.info("\n\n**** training job has started ... ****\n\n")

    # Step 3: Initialize PrimaryReader to read data
    primary_reader = PrimaryReader(spark_session=spark_session, env=env, config=config)

    # Step 4: Initialize PrimaryRunner to run data processing
    primary_runner = PrimaryRunner(fetch_source=primary_reader, spark_session=spark_session)

    comments_with_sentiment = primary_runner.run_primary_runner()

    primary_writer = PrimaryWriter(env=env)
    primary_writer.write(comments_with_sentiment, PrimaryConstants.MODE_APPEND)




if __name__ == "__main__":
    import sys

    if len(sys.argv) != 3:
        logger.error("Usage: main.py <env> <absolute_config_path>")
        sys.exit(1)

    # Pass environment and configuration path from the command-line arguments
    main(sys.argv[1], sys.argv[2])
