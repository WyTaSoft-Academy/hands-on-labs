class PrimaryConstants:
  """
  Class to store primary constants used throughout the Spark application.
  This centralized management of constants helps ensure consistency and easier maintenance.

  Constants:
  - APPLICATION_NAME: Used as the name of the Spark application in the UI and logs.
  - CLIENTS: Refers to the dataset or table name for clients.
  - ORDERS: Refers to the dataset or table name for orders.

  :author: Mehdi TAJMOUATI
  :note: For queries or more detailed information on the use of these constants in Spark projects,
         contact mehdi.tajmouati@wytasoft.com
  """

  # Application name for Spark UI and log identification.
  APPLICATION_NAME = "wytasoft_training_academy_kafka"

  COMMENTS = "comments"
  KAFKA_TOPIC_NAME = "comments"
  KAFKA_BOOTSTRAP_SERVERS = "kafka:9092"
  # Mode for writing data (e.g., in Spark DataFrame write operations).
  MODE_APPEND = "append"
  MODE_OVERWRITE = "overwrite"