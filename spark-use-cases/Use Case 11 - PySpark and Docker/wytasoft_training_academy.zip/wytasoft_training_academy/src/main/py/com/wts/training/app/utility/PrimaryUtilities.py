import logging
from pyspark.sql import SparkSession, DataFrame, Column
from pyspark.sql.functions import lit
from pyspark.sql.types import StructType
from datetime import datetime
import yaml

from src.main.py.com.wts.training.app.utility.PrimaryConstants import PrimaryConstants


class PrimaryUtilities:
  """
  Utility class providing methods for interacting with HDFS, reading and writing DataFrames,
  and handling date conversions, tailored for Spark applications.
  """
  log = logging.getLogger(__name__)

  @staticmethod
  def get_max_partition(path: str, column_partitioned: str = "date", spark: SparkSession = None) -> str:
    """
    Fetches the most recent partition based on a date column from a specified HDFS path.

    :param path: The HDFS directory to scan.
    :param column_partitioned: The partition column, defaulted to 'date'.
    :param spark: The Spark session.
    :return: The most recent partition date as a string, or a far-future date if no partitions exist.
    """
    try:
      fs = spark._jvm.org.apache.hadoop.fs.FileSystem.get(spark._jsc.hadoopConfiguration())
      list_of_insert_dates = fs.listStatus(spark._jvm.org.apache.hadoop.fs.Path(path))
      partition_folders = [str(folder.getPath()) for folder in list_of_insert_dates if folder.isDirectory()]

      filtered_folders = [folder.split(f"{column_partitioned}=")[1] for folder in partition_folders if f"{column_partitioned}=" in folder]
      if filtered_folders:
        dates = [PrimaryUtilities.convert_string_to_date(date_str, "%Y-%m-%d") for date_str in filtered_folders]
        max_date = PrimaryUtilities.date_to_str_and_reformat(max(dates), "%Y-%m-%d")
        PrimaryUtilities.log.info(f"Max partition by {column_partitioned}: {max_date}")
        return max_date
      else:
        PrimaryUtilities.log.info(f"No partitions by {column_partitioned} in {path}")
        return "2999-01-01"
    except Exception as e:
      PrimaryUtilities.log.error(f"Error while getting max partition: {e}")
      raise ValueError("Error fetching partition")

  @staticmethod
  def read_dataframe(source_name: str, schema: StructType, spark_session: SparkSession, env: str, config: dict, file_format: str = "parquet", options: dict = None,  is_condition: bool = False, condition: Column = None) -> DataFrame:
    """
    Reads a DataFrame from a specified source path using a predefined schema.

    :param source_name: The identifier for the data source to load.
    :param schema: The schema to apply to the DataFrame.
    :param spark_session: SparkSession to handle DataFrame operations.
    :param env: Environment used for building the data path.
    :param config: Additional configuration settings.
    :param is_condition: Boolean indicating if a condition should be applied.
    :param condition: The conditional filter to apply, if any.
    :return: DataFrame loaded from the specified path.
    """
    PrimaryUtilities.log.info("Reading file to create DataFrame...")
    effective_condition = condition if is_condition else lit(True)

    table_name = source_name.lower()
    input_path = config[PrimaryConstants.APPLICATION_NAME][table_name][env]

#    if source_name == PrimaryConstants.ORDERS:
#      partition_value = PrimaryUtilities.get_max_partition(f"{input_path}{table_name}/", spark_session=spark_session)
#      table_name = f"orders/date={partition_value}"

    PrimaryUtilities.log.info(f"Loading {source_name} from {input_path}{table_name}")

    # Use spark_session.read.format to dynamically set the file format
    reader = spark_session.read.format(file_format).schema(schema)

    # Apply additional read options if provided
    if options:
      for key, value in options.items():
        reader = reader.option(key, value)

    dataframe = reader.load(f"{input_path}{table_name}/").where(effective_condition)

    return dataframe

  @staticmethod
  def convert_string_to_date(s: str, format_type: str) -> datetime:
    """
    Converts a string to a Date object using the specified date format.
    """
    return datetime.strptime(s, format_type)

  @staticmethod
  def date_to_str_and_reformat(date: datetime, format_str: str) -> str:
    """
    Reformats a Date object to a string using the specified date format.
    """
    return date.strftime(format_str)

  @staticmethod
  def write_dataframe(dataframe: DataFrame, mode: str, num_partition: int, env: str):
    """
    Writes a DataFrame to a specified path with a given mode and number of partitions.

    :param dataframe: The DataFrame to write.
    :param mode: The save mode (e.g., "overwrite", "append").
    :param num_partition: The number of partitions to use when writing the DataFrame.
    :param env: Environment string for the write operation.
    """
    dataframe.show()
    PrimaryUtilities.log.info(f"Writing DataFrame (mode: {mode}, num partitions: {num_partition})...")

    dataframe.write.mode("overwrite").json("/prd/project/datalake/recommendation/")

    PrimaryUtilities.log.info("Write operation completed.")

  @staticmethod
  def read_yaml_config(file_path):
    with open(file_path, 'r') as stream:
      try:
        config = yaml.safe_load(stream)
        return config
      except yaml.YAMLError as exc:
        print(exc)
