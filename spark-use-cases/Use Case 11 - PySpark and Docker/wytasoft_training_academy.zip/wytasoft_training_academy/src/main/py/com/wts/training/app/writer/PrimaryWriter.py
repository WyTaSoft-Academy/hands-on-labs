import logging
from pyspark.sql import DataFrame

from src.main.py.com.wts.training.app.utility.PrimaryUtilities import PrimaryUtilities


class PrimaryWriter:
    """
  A class responsible for writing DataFrames to storage using specified parameters.
  This class leverages utility methods from `PrimaryUtilities` to perform the write operation.

  :param env: The environment string (e.g., 'dev', 'test', 'prod').
  :note: Ensure that the SparkSession is properly configured and active before using this class.
  """

    def __init__(self, env: str):
        """
    Initializes the PrimaryWriter with the specified environment.

    :param env: Environment string, such as 'dev', 'test', or 'prod'.
    """
        self.env = env
        self.log = logging.getLogger(self.__class__.__name__)

    def write(self, data_frame: DataFrame, mode: str, num_partitions: int) -> None:
        """
    Write a DataFrame to storage with the specified mode and number of partitions.
    This method uses `PrimaryUtilities.write_dataframe` to perform the actual write operation.

    :param data_frame: The DataFrame to write to storage.
    :param mode: The write mode (e.g., "overwrite", "append").
    :param num_partitions: The number of partitions to use when writing the DataFrame.
    """
        self.log.info(f"Writing DataFrame in {self.env} environment with mode: {mode} and partitions: {num_partitions}")
        data_frame.printSchema()
        PrimaryUtilities.write_dataframe(data_frame, mode, num_partitions, self.env)

    def write(self, data_frame: DataFrame, mode: str) -> None:
        """
    Write a DataFrame to storage with the specified mode and number of partitions.
    This method uses `PrimaryUtilities.write_dataframe` to perform the actual write operation.

    :param data_frame: The DataFrame to write to storage.
    :param mode: The write mode (e.g., "overwrite", "append").
    :param num_partitions: The number of partitions to use when writing the DataFrame.
    """
        # Step 6: Write the results to the console
        sentiment_query = (data_frame.writeStream
         .outputMode(mode)
         .format("console")
         .option("truncate", False)
         .start())

        sentiment_query.awaitTermination()